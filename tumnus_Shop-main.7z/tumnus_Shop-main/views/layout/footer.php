</div>
</div>

			<!-- PIE DE PÁGINA -->
			 <footer>

        <div class="container__footer">
            <div class="box__footer">
                <div class="logo">
                    <img src="assets/img/tummus.png" alt="">
                </div>
                <div class="terms">
                    <p class="text"><b>Tumnus es una agencia de cupones que muestra muchas ofertas de las mas grandes empresas a sus clientes.</b></p>
                </div>
            </div>            
            <div class="box__footer">
                <h2 class="text">Contacto</h2>
                <a href="#" class="text">Ciudadela Don Bosco, Soyapango, San Salvador.</a>
                <a href="#" class="text">+503 7136-4955</a>
                <a href="#" class="text">cuponera@gmail.com</a>      
            </div>

            <div class="box__footer">
                <h2 class="text">Redes Sociales</h2>
                <a target=”_blank” href="https://www.facebook.com/willian.reyes.71" class="text"> <i class="fab fa-facebook-square"></i> Facebook</a>
                <a target=”_blank” href="https://www.instagram.com/jeff_elmajo/?hl=es" class="text"><i class="fab fa-instagram-square"></i> Instagram</a>
            </div>

        </div>

        <div class="box__copyright">
            <hr>
            <p class="text">Todos los derechos reservados © 2023 <b>TUMNUS</b></p>
        </div>
    </footer>
		</div>
	</body>
</html>